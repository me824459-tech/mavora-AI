import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import os from 'node:os';
import fs from 'node:fs/promises';
import path from 'node:path';

const providerRequests = [];
const provider = http.createServer(async (req, res) => {
  const chunks = [];
  for await (const c of req) chunks.push(c);
  const body = chunks.length ? JSON.parse(Buffer.concat(chunks).toString()) : undefined;
  providerRequests.push({ method: req.method, url: req.url, body, auth: req.headers.authorization });
  res.setHeader('Content-Type', 'application/json');
  if (req.method === 'POST' && req.url.includes('/text-to-video')) return res.end(JSON.stringify({ request_id: 'test-request-text-123', status: 'queued' }));
  if (req.method === 'POST' && req.url.includes('/image-to-video')) return res.end(JSON.stringify({ request_id: 'test-request-image-456', status: 'queued' }));
  if (req.method === 'GET' && req.url.includes('/status')) return res.end(JSON.stringify({ status: 'completed', video: { url: 'https://cdn.example.org/video.mp4' } }));
  if (req.method === 'POST' && req.url.includes('/cancel')) { res.statusCode = 202; return res.end('{}'); }
  res.statusCode = 404; return res.end('{}');
});
const listen = (server, host = '127.0.0.1') => new Promise(resolve => server.listen(0, host, resolve));
const close = server => new Promise(resolve => server.close(resolve));
await listen(provider);
const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'mavora-test-'));
process.env.NO_LISTEN = '1';
process.env.NODE_ENV = 'test';
process.env.HF_API_BASE_URL = `http://127.0.0.1:${provider.address().port}`;
process.env.HF_API_KEY = 'a-test-key';
process.env.APP_PASSWORD = 'a-strong-test-password';
process.env.TEST_DATA_DIR = dir;
process.env.HOST = '127.0.0.1';
const { server } = await import('../server.mjs');
await listen(server);
const root = `http://127.0.0.1:${server.address().port}`;
let cookie = '';
async function req(endpoint, method = 'GET', data, auth = true) {
  const result = await fetch(root + endpoint, {
    method,
    headers: { ...(auth ? { Cookie: cookie } : {}), ...(data === undefined ? {} : { 'Content-Type': 'application/json' }) },
    ...(data === undefined ? {} : { body: JSON.stringify(data) }),
  });
  return { status: result.status, data: await result.json() };
}

test('site serves HTML and is locked for a single owner', async () => {
  const page = await fetch(root);
  assert.equal(page.status, 200);
  assert.match(await page.text(), /MAVORA/);
  const session = await req('/api/session');
  assert.equal(session.data.authenticated, false);
  assert.equal((await req('/api/jobs')).status, 401);
});
test('login, submit text, poll status, and submit image', async () => {
  const response = await fetch(root + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: 'a-strong-test-password' }) });
  assert.equal(response.status, 200);
  cookie = response.headers.get('set-cookie').split(';')[0];
  assert.equal((await req('/api/session')).data.configured, true);
  const submitted = await req('/api/generate', 'POST', { mode: 'text', prompt: 'A camera flies above a valley', duration: 5, resolution: '720p', aspectRatio: '16:9', audio: true });
  assert.equal(submitted.status, 202);
  assert.equal(submitted.data.job.id, 'test-request-text-123');
  const pathText = providerRequests.find(r => r.url.includes('/text-to-video'));
  assert.equal(pathText.auth, 'Key a-test-key');
  assert.equal(pathText.body.aspect_ratio, '16:9');
  const done = await req('/api/jobs/test-request-text-123');
  assert.equal(done.data.job.status, 'completed');
  assert.equal(done.data.job.videoUrl, 'https://cdn.example.org/video.mp4');
  const image = await req('/api/generate', 'POST', { mode: 'image', prompt: 'Animate the portrait', imageUrl: 'https://cdn.example.org/input.jpg', duration: 8, resolution: '1080p', audio: false });
  assert.equal(image.status, 202);
  const pathImage = providerRequests.find(r => r.url.includes('/image-to-video'));
  assert.equal(pathImage.body.image_url, 'https://cdn.example.org/input.jpg');
  assert.equal(Object.prototype.hasOwnProperty.call(pathImage.body, 'aspect_ratio'), false);
  assert.equal((await req('/api/jobs')).data.jobs.length, 2);
});
test('rejects malformed generation and prevents random job lookups', async () => {
  assert.equal((await req('/api/generate', 'POST', { mode: 'text', prompt: '', duration: 5 })).status, 400);
  assert.equal((await req('/api/generate', 'POST', { mode: 'image', prompt: 'x', duration: 5, imageUrl: 'http://example.org/notsecure.jpg' })).status, 400);
  assert.equal((await req('/api/jobs/somebody-elses-request')).status, 404);
  assert.equal((await req('/api/upload', 'POST', {})).status, 400);
});
test('cleanup and persisted jobs', async () => {
  const jobsFile = JSON.parse(await fs.readFile(path.join(dir, 'jobs.json'), 'utf8'));
  assert.equal(jobsFile.length, 2);
  await close(server); await close(provider); await fs.rm(dir, { recursive: true, force: true });
});
